/************************************************************************************
 *  File:     main.c
 *  Purpose:  Cortex-M4 main file.
 ************************************************************************************/


#include "stm32f4xx.h"

#include "lib_adc.h"

int main(void)
    {
    uint16_t x;

    /// initialisation du CAN3 resolution 8 bits
    /// canal 7 => broche PF9 (#12)
    LibADC_Init(ADC3, ADC_Channel_7, ADC_Resolution_8b);

    while (1)
    {
    x= LibADC_Read(ADC3, ADC_Channel_7);   // acquisition
    }
}

