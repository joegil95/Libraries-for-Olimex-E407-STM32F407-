/*
Gestion des interruptions soous EmIde / GCCAVR:

Ajouter dans Project > Build options > Compiler settings > #defines
les definitions XXX_HANDLER (en majuscules) correspondant aux l'interruptions
que l'on souhaite prendre en compte et d�finir dans le programme la routine
associ�e comme ci-dessous.
*/

#ifdef WWDG_HANDLER
    void WWDG_Handler(void);		        	// WATCHDOG=0
    #warning Using Interrupt 0
#endif

#ifdef PVD_HANDLER
    void PVD_Handler(void);		        	    // PVD=1
    #warning Using Interrupt 1
#endif

#ifdef TAMP_STAMP_HANDLER
    void TAMP_STAMP_Handler(void);	    	    // TAMPER=2
    #warning Using Interrupt 2
#endif

#ifdef RTC_WKUP_HANDLER
    void RTC_WKUP_Handler(void);		        // RTC=3
    #warning Using Interrupt 3
#endif

#ifdef FLASH_HANDLER
    void FLASH_Handler(void);		    	    // FLASH=4
    #warning Using Interrupt 4
#endif

#ifdef RCC_HANDLER
    void RCC_Handler(void);			            // RCC=5
    #warning Using Interrupt 5
#endif

#ifdef EXTI0_HANDLER
    void EXTI0_Handler(void);		       	    // EXTI=6
    #warning Using Interrupt 6
#endif

#ifdef EXTI1_HANDLER
    void EXTI1_Handler(void);		    	    // EXTI=7
    #warning Using Interrupt 7
#endif

#ifdef EXTI2_HANDLER
    void EXTI2_Handler(void);			        // EXTI=8
    #warning Using Interrupt 8
#endif

#ifdef EXTI3_HANDLER
    void EXTI3_Handler(void);			        // EXTI=9
    #warning Using Interrupt 9
#endif

#ifdef EXTI4_HANDLER
    void EXTI4_Handler(void);			        // EXTI=10
    #warning Using Interrupt 10
#endif

#ifdef DMA1_S0_HANDLER
    void DMA1_S0_Handler(void);	                // DMA1=11
    #warning Using Interrupt 11
#endif

#ifdef DMA1_S1_HANDLER
    void DMA1_S1_Handler(void);     	        // DMA1=12
    #warning Using Interrupt 12
#endif

#ifdef DMA1_S2_HANDLER
    void DMA1_S2_Handler(void);     	        // DMA1=13
    #warning Using Interrupt 13
#endif

#ifdef DMA1_S3_HANDLER
    void DMA1_S3_Handler(void);     	        // DMA1=14
    #warning Using Interrupt 14
#endif

#ifdef DMA1_S4_HANDLER
    void DMA1_S4_Handler(void);     	        // DMA1=15
    #warning Using Interrupt 15
#endif

#ifdef DMA1_S5_HANDLER
    void DMA1_S5_Handler(void);     	        // DMA1=16
    #warning Using Interrupt 16
#endif

#ifdef DMA1_S6_HANDLER
    void DMA1_S6_Handler(void);    	            // DMA1= 17
    #warning Using Interrupt 17
#endif

#ifdef ADC_HANDLER
    void ADC_Handler(void);		        	    // ADC1-2-3=18
    #warning Using Interrupt 18
#endif

#ifdef CAN1_TX_HANDLER
    void CAN1_TX_Handler(void);		            // CAN1=19
    #warning Using Interrupt 19
#endif

#ifdef CAN1_RX0_HANDLER
    void CAN1_RX0_Handler(void);	        	// CAN1=20
    #warning Using Interrupt 20
#endif

#ifdef CAN1_RX1_HANDLER
    void CAN1_RX1_Handler(void);	        	// CAN1=21
    #warning Using Interrupt 21
#endif

#ifdef CAN1_SCE_HANDLER
    void CAN1_SCE_Handler(void);	        	// CAN1=22
    #warning Using Interrupt 22
#endif

#ifdef EXTI9_5_HANDLER
    void EXTI9_5_Handler(void);	        	    // EXTI=23
    #warning Using Interrupt 23
#endif

#ifdef TIM1_BRK_TIM9_HANDLER
    void TIM1_BRK_TIM9_Handler(void);	        // TIM1=24
    #warning Using Interrupt 24
#endif

#ifdef TIM1_UP_TIM10_HANDLER
    void TIM1_UP_TIM10_Handler(void);	        // TIM1=25
    #warning Using Interrupt 25
#endif

#ifdef TIM1_TRG_COM_TIM11_HANDLER
    void TIM1_TRG_COM_TIM11_Handler(void);	    // TIM1=26
    #warning Using Interrupt 26
#endif

#ifdef TIM1_CC_HANDLER
    void TIM1_CC_Handler(void);		            // TIM1=27
    #warning Using Interrupt 27
#endif

#ifdef TIM2_HANDLER
    void TIM2_Handler(void);   		            // TIM2=28
    #warning Using Interrupt 28
#endif

#ifdef TIM3_HANDLER
    void TIM3_Handler(void);			        // TIM3=29
    #warning Using Interrupt 29
#endif

#ifdef TIM4_HANDLER
    void TIM4_Handler(void);			        // TIM4=30
    #warning Using Interrupt 30
#endif

#ifdef I2C1_EV_HANDLER
    void I2C1_EV_Handler(void);	        	    // I2C1=31
    #warning Using Interrupt 31
#endif

#ifdef I2C1_ER_HANDLER
    void I2C1_ER_Handler(void);	        	    // I2C1=32
    #warning Using Interrupt 32
#endif

#ifdef I2C2_EV_HANDLER
    void I2C2_EV_Handler(void);	        	    // I2C2=33
    #warning Using Interrupt 33
#endif

#ifdef I2C2_ER_HANDLER
    void I2C2_ER_Handler(void);	        	    // I2C2=34
    #warning Using Interrupt 34
#endif

#ifdef SPI1_HANDLER
    void SPI1_Handler(void);		        	// SPI1=35
    #warning Using Interrupt 35
#endif

#ifdef SPI2_HANDLER
    void SPI2_Handler(void);		        	// SPI2=36
    #warning Using Interrupt 36
#endif

#ifdef USART1_HANDLER
    void USART1_Handler(void);	        	    // USART1=37
    #warning Using Interrupt 37
#endif

#ifdef USART2_HANDLER
    void USART2_Handler(void);	                // USART2=38
    #warning Using Interrupt 38
#endif

#ifdef USART3_HANDLER
    void USART3_Handler(void);	                // USART3=39
    #warning Using Interrupt 39
#endif

#ifdef EXTI15_10_HANDLER
    void EXTI15_10_Handler(void);              // EXTI=40
    #warning Using Interrupt 40
#endif

#ifdef RTC_ALARM_HANDLER
    void RTC_ALARM_Handler(void);	            // RTC=41
    #warning Using Interrupt 41
#endif

#ifdef OTG_FS_WKUP_HANDLER
    void OTG_FS_WKUP_Handler(void);	            // USB=42
    #warning Using Interrupt 42
#endif

#ifdef TIM8_BRK_TIM12_HANDLER
    void TIM8_BRK_TIM12_Handler(void);          // TIM8=43
    #warning Using Interrupt 43
#endif

#ifdef TIM8_UP_TIM13_HANDLER
    void TIM8_UP_TIM13_Handler(void);           // TIM8=44
    #warning Using Interrupt 44
#endif

#ifdef TIM8_TRG_COM_TIM14_HANDLER
    void TIM8_TRG_COM_TIM14_Handler(void);	    // TIM8=45
    #warning Using Interrupt 45
#endif

#ifdef TIM8_CC_HANDLER
    void TIM8_CC_Handler(void);		            // TIM8=46
    #warning Using Interrupt 46
#endif

#ifdef DMA1_S7_HANDLER
    void DMA1_S7_Handler(void);	                // DMA1=47
    #warning Using Interrupt 47
#endif

#ifdef FSMC_HANDLER
    void FSMC_Handler(void);			        // FSMC=48
    #warning Using Interrupt 48
#endif

#ifdef SDIO_HANDLER
    void SDIO_Handler(void);			        // SDIO=49
    #warning Using Interrupt 49
#endif

#ifdef TIM5_HANDLER
    void TIM5_Handler(void);			        // TIM5=50
    #warning Using Interrupt 50
#endif

#ifdef SPI3_HANDLER
    void SPI3_Handler(void);			        // SPI3=51
    #warning Using Interrupt 51
#endif

#ifdef UART4_HANDLER
    void UART4_Handler(void);			        // UART4=52
    #warning Using Interrupt 52
#endif

#ifdef UART5_HANDLER
    void UART5_Handler(void);			        // UART5=53
    #warning Using Interrupt 63
#endif

#ifdef TIM6_DAC_HANDLER
    void TIM6_DAC_Handler(void);		        // TIM6-DAC1=54
    #warning Using Interrupt 54
#endif

#ifdef TIM7_HANDLER
    void TIM7_Handler(void);			        // TIM7=55
    #warning Using Interrupt 55
#endif

#ifdef DMA2_S0_HANDLER
    void DMA2_S0_Handler(void);	                // DMA2=56
    #warning Using Interrupt 56
#endif

#ifdef DMA2_S1_HANDLER
    void DMA2_S1_Handler(void);	                // DMA2=57
    #warning Using Interrupt 57
#endif

#ifdef DMA2_S2_HANDLER
    void DMA2_S2_Handler(void);	                // DMA2=58
    #warning Using Interrupt 58
#endif

#ifdef DMA2_S3_HANDLER
    void DMA2_S3_Handler(void);	                // DMA2=59
    #warning Using Interrupt 59
#endif

#ifdef DMA2_S4_HANDLER
    void DMA2_S4_Handler(void);	                // DMA2=60
    #warning Using Interrupt 60
#endif

#ifdef ETH_HANDLER
    void ETH_Handler(void);			            // Ethernet=61
    #warning Using Interrupt 61
#endif

#ifdef ETH_WKUP_HANDLER
    void ETH_WKUP_Handler(void);		        // Ethernet=62
    #warning Using Interrupt 62
#endif

#ifdef CAN2_TX_HANDLER
    void CAN2_TX_Handler(void);		            // CAN2=63
    #warning Using Interrupt 63
#endif

#ifdef CAN2_RX0_HANDLER
    void CAN2_RX0_Handler(void);		        // CAN2=64
    #warning Using Interrupt 64
#endif

#ifdef CAN2_RX1_HANDLER
    void CAN2_RX1_Handler(void);		        // CAN2=65
    #warning Using Interrupt 65
#endif

#ifdef CAN2_SCE_HANDLER
    void CAN2_SCE_Handler(void);		        // CAN2=66
    #warning Using Interrupt 66
#endif

#ifdef OTG_FS_HANDLER
    void OTG_FS_Handler(void);		            // USB=67
    #warning Using Interrupt 67
#endif

#ifdef DMA2_S5_HANDLER
    void DMA2_S5	                            // DMA2=68
    #warning Using Interrupt 68
#endif

#ifdef DMA2_S6_HANDLER
    void DMA2_S6	                            // DMA2=69
    #warning Using Interrupt 69
#endif

#ifdef DMA2_S7_HANDLER
    void DMA2_S7	                            // DMA2=70
    #warning Using Interrupt 70
#endif

#ifdef USART6_HANDLER
    void USART6_Handler(void);		            // USART6=71
    #warning Using Interrupt 71
#endif

#ifdef I2C3_EV_HANDLER
    void I2C3_EV_Handler(void);		            // I2C3=72
    #warning Using Interrupt 72
#endif

#ifdef I2C3_ER_HANDLER
    void I2C3_ER_Handler(void);		            // I2C3=73
    #warning Using Interrupt 73
#endif

#ifdef OTG_HS_EP1_OUT_HANDLER
    void OTG_HS_EP1_OUT_Handler(void);	        // USB=74
    #warning Using Interrupt 74
#endif

#ifdef OTG_HS_EP1_IN_HANDLER
    void OTG_HS_EP1_IN_Handler(void);	        // USB=75
    #warning Using Interrupt 75
#endif

#ifdef OTG_HS_WKUP_HANDLER
    void OTG_HS_WKUP_Handler(void);		        // USB=76
    #warning Using Interrupt 76
#endif

#ifdef OTG_HS_HANDLER
    void OTG_HS_Handler(void);		            // USB=77
    #warning Using Interrupt 77
#endif

#ifdef DCMI_HANDLER
    void DCMI_Handler(void);			        // DCMI=78
    #warning Using Interrupt 78
#endif

#ifdef CRYP_HANDLER
    void CRYP_Handler(void);			        // CRYP=79
    #warning Using Interrupt 79
#endif

#ifdef HASH_RNG_HANDLER
    void HASH_RNG_Handler(void);		        // Hash=80
    #warning Using Interrupt 80
#endif

#ifdef FPU_HANDLER
    void FPU_Handler(void);			            // FPU=81
    #warning Using Interrupt 81
#endif
