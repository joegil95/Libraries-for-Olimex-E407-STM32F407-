/************************************************************************************
 *  File:     main.c
 *  Purpose:  Cortex-M4 main file.
 ************************************************************************************/


/// Connecter une led + r�sistance enter GND et PD12 (broche #15)
/// Declarer TIM2_HANDLER dans les options du projet

#include "stm32f4xx.h"

#include "stm32f4xx_gpio.h"
#include "stm32f4xx_rcc.h"
#include "stm32f4xx_tim.h"

#include "lib_timer.h"

#include "misc.h"
#include "interrupts.h"


void Init_Ports()
    {
    RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOD, ENABLE);

    GPIO_InitTypeDef gpioStructure;
    gpioStructure.GPIO_Pin = GPIO_Pin_12;
    gpioStructure.GPIO_Mode = GPIO_Mode_OUT;
    gpioStructure.GPIO_Speed = GPIO_Speed_2MHz;
    GPIO_Init(GPIOD, &gpioStructure);

    GPIO_WriteBit(GPIOD, GPIO_Pin_12, 0);
    }


/// Timer avec interruptions
void main()
{
    Init_Ports();

    LibTimer_Init(TIM2, 40000, 500);
    LibTimer_Interrupts(TIM2, ENABLE);

    while(1)
    {
        int x= 0;
    }
}


void TIM2_Handler()
{
    if (TIM_GetITStatus(TIM2, TIM_IT_Update) != RESET)
    {
        GPIO_ToggleBits(GPIOD, GPIO_Pin_12);

        TIM_ClearITPendingBit(TIM2, TIM_IT_Update);
    }
}


/// Timer sans interruptions (polling)
/*
void main()
{
    Init_Ports();

    LibTimer_Init(TIM2, 40000, 500);

    while(1)
    {
        uint32_t timerValue= TIM_GetCounter(TIM2);
        if (timerValue == 400)
            GPIO_WriteBit(GPIOD, GPIO_Pin_12, Bit_SET);
        else if (timerValue == 500)
            GPIO_WriteBit(GPIOD, GPIO_Pin_12, Bit_RESET);
    }
}
*/
