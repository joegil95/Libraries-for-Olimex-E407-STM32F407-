/************************************************************************************
 *  File:     main.c
 *  Purpose:  Cortex-M4 main file.
 ************************************************************************************/


#include "stm32f4xx.h"

#include "stm32f4xx_dac.h"

#include "lib_dac.h"


int main(void)
    {
    uint16_t x;

    /// initialisation du DAC1 resolution 12 bits (broche PA4)
    LibDAC_Init(DAC1);

    while (1)
        {
        LibDAC_Output(DAC1, 3000);      // tension 2,4 V

        for (long t= 0 ; t < 100000 ; t++);
        }
    }

