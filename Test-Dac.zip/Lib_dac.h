/**
 * DAC Library for STM32F4xx devices
 */


#ifndef TM_DAC_H
#define TM_DAC_H 110

/* C++ detection */
#ifdef __cplusplus
extern C {
#endif

//  This library provides 12-bit digital to analog output, values from 0 to 4095

/**
 *  DAC	        Output
 *
 *  DAC1		PA4
 *  DAC2		PA5
 */

#include "stm32f4xx.h"

#include "stm32f4xx_gpio.h"
#include "stm32f4xx_rcc.h"
#include "stm32f4xx_dac.h"

#include "lib_gpio.h"


#define	DAC1    DAC_Channel_1       // DAC channel 1
#define	DAC2    DAC_Channel_2       // DAC channel 2


void LibDAC_Init(uint32_t DACx);

void LibDAC_Output(uint32_t DACx, uint16_t value);


/* C++ detection */
#ifdef __cplusplus
}
#endif

#endif
