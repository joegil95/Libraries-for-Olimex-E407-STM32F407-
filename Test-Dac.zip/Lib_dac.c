/**
 * Copyright (C) JG 2016
 */

#include "lib_dac.h"


// Les DAC fonctionnent en 3,3 V

/**
 * @brief  Initialize DAC channel and pin
 * @param  DACx = DAC1 or DAC2
 * @retval None
 */
void LibDAC_Init(uint32_t DACx)
    {
	DAC_InitTypeDef DAC_InitStruct;
	uint16_t GPIO_Pin;

	// DAC Periph clock enable
    RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOA, ENABLE);
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_DAC, ENABLE);

	// Select GPIO pin
	if (DACx == DAC1)
		GPIO_Pin = GPIO_PIN_4;
	else
		GPIO_Pin = GPIO_PIN_5;

	// Initialize GPIO pin
	LibGPIO_Init(GPIOA, GPIO_Pin, LibGPIO_Mode_AN, LibGPIO_OType_PP, LibGPIO_PuPd_NOPULL, LibGPIO_Speed_Fast);

	// Set DAC options
	DAC_InitStruct.DAC_Trigger = DAC_Trigger_None;
	DAC_InitStruct.DAC_WaveGeneration = DAC_WaveGeneration_None;
	DAC_InitStruct.DAC_OutputBuffer = DAC_OutputBuffer_Enable;

	// Init and enable DAC
	if (DACx == DAC1)
        {
		DAC_Init(DAC_Channel_1, &DAC_InitStruct);
		DAC_Cmd(DAC_Channel_1, ENABLE);
        }
    else
        {
		DAC_Init(DAC_Channel_2, &DAC_InitStruct);
		DAC_Cmd(DAC_Channel_2, ENABLE);
        }
    }


/**
 * @brief  Output analog voltage to ADCx
 * @param  DACx = DAC1 or DAC2
 * @param  value = 12-bit unsigned value from 0 to 4095
 * @retval None
 */
void LibDAC_Output(uint32_t DACx, uint16_t value)
    {
	if (value > 4095) value = 4095;

	// Set 12-bit value right aligned
	if (DACx == DAC1) DAC_SetChannel1Data(DAC_Align_12b_R, value);
	else DAC_SetChannel2Data(DAC_Align_12b_R, value);
    }
